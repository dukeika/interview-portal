// File: src/components/company/ScheduleInterviewModal.tsx
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { X, Calendar, Clock, Video, Phone, MapPin, User } from "lucide-react";
import { Application, Interview } from "./types";

interface ScheduleInterviewModalProps {
  applications: Application[];
  onSchedule: (interviewData: Partial<Interview>) => Promise<void>;
  onClose: () => void;
}

export default function ScheduleInterviewModal({
  applications,
  onSchedule,
  onClose,
}: ScheduleInterviewModalProps) {
  const [selectedApplication, setSelectedApplication] = useState<Application | null>(null);
  const [formData, setFormData] = useState({
    type: "video" as Interview["type"],
    scheduledAt: "",
    duration: 60,
    interviewer: "",
    interviewerTitle: "",
    interviewerEmail: "",
    description: "",
    location: "",
    meetingUrl: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedApplication) return;

    setIsSubmitting(true);
    try {
      const interviewData: Partial<Interview> = {
        applicationId: selectedApplication.id,
        jobId: selectedApplication.jobId,
        jobTitle: selectedApplication.jobTitle,
        candidateId: selectedApplication.candidateId,
        candidateName: selectedApplication.candidateName,
        candidateEmail: selectedApplication.candidateEmail,
        ...formData,
        meetingUrl: formData.type !== "in_person" ? formData.meetingUrl : null,
        location: formData.type === "in_person" ? formData.location : null,
      };

      await onSchedule(interviewData);
      onClose();
    } catch (error) {
      console.error("Failed to schedule interview:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const generateMeetingUrl = () => {
    if (formData.type === "video") {
      // In real implementation, this would integrate with Zoom/Teams API
      const meetingId = Math.random().toString(36).substring(7);
      setFormData({
        ...formData,
        meetingUrl: `https://zoom.us/j/${meetingId}`,
      });
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto m-4">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">
            Schedule Interview
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Application Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Select Candidate
            </label>
            <select
              value={selectedApplication?.id || ""}
              onChange={(e) => {
                const app = applications.find(a => a.id === e.target.value);
                setSelectedApplication(app || null);
              }}
              className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            >
              <option value="">Choose a candidate...</option>
              {applications.map((app) => (
                <option key={app.id} value={app.id}>
                  {app.candidateName} - {app.jobTitle}
                </option>
              ))}
            </select>
          </div>

          {/* Interview Type */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Interview Type
            </label>
            <div className="grid grid-cols-3 gap-3">
              {[
                { value: "video", label: "Video Call", icon: Video },
                { value: "phone", label: "Phone Call", icon: Phone },
                { value: "in_person", label: "In Person", icon: MapPin },
              ].map(({ value, label, icon: Icon }) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setFormData({ ...formData, type: value as Interview["type"] })}
                  className={`p-3 border rounded-md flex flex-col items-center space-y-2 transition-colors ${
                    formData.type === value
                      ? "border-blue-500 bg-blue-50 text-blue-700"
                      : "border-gray-300 hover:border-gray-400"
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-sm font-medium">{label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Date and Time */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Calendar className="w-4 h-4 inline mr-1" />
                Date & Time
              </label>
              <input
                type="datetime-local"
                value={formData.scheduledAt}
                onChange={(e) => setFormData({ ...formData, scheduledAt: e.target.value })}
                className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Clock className="w-4 h-4 inline mr-1" />
                Duration (minutes)
              </label>
              <select
                value={formData.duration}
                onChange={(e) => setFormData({ ...formData, duration: parseInt(e.target.value) })}
                className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value={30}>30 minutes</option>
                <option value={45}>45 minutes</option>
                <option value={60}>1 hour</option>
                <option value={90}>1.5 hours</option>
                <option value={120}>2 hours</option>
              </select>
            </div>
          </div>

          {/* Interviewer Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-gray-900">
              <User className="w-5 h-5 inline mr-2" />