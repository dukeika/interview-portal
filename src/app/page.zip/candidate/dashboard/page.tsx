// Replace your src/app/candidate/dashboard/page.tsx with this:
"use client";

import CandidateDashboard from "@/components/candidate/CandidateDashboard";

export default function CandidateDashboardPage() {
  return <CandidateDashboard />;
}
